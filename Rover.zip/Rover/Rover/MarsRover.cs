﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rover
{
    public class MarsRover
    {
        public int x;
        public int y;
        public string direction;

        public MarsRover(string location)
        {
            x = Int32.Parse(location.Split(' ')[0]);
            y = Int32.Parse(location.Split(' ')[1]);
            direction = location.Split(' ')[2];
        }

        //<Summary>
        //This function spin the direction when 'L' is passed
        //</summary>
        //<params>
        //No argument
        //</params>
        //<output>
        //null
        //</output>
        public void SpinLeft()
        {
            switch (direction)
            {
                case "N":
                    direction = "W";
                    break;
                case "E":
                    direction = "N";
                    break;
                case "S":
                    direction = "E";
                    break;
                case "W":
                    direction = "S";
                    break;
                default:
                    throw new ArgumentException();
            }
        }


        //<Summary>
        //This function spin the direction when 'R' is passed
        //</summary>
        //<params>
        //No argument
        //</params>
        //<output>
        //null
        //</output>
        public void SpinRight()
        {
            switch (direction)
            {
                case "N":
                    direction = "E";
                    break;
                case "E":
                    direction = "S";
                    break;
                case "S":
                    direction = "W";
                    break;
                case "W":
                    direction = "N";
                    break;
                default:
                    throw new ArgumentException();
            }
        }

        //<Summary>
        //This function moves the rover one step forward or backward
        //</summary>
        //<params>
        //GridSize of string datatype is passed
        //</params>
        //<output>
        //null
        //</output>
        public void StepForward(string plateauSize)
        {
            int xAxis = Int32.Parse(plateauSize.Split('x')[0]);
            int yAxis = Int32.Parse(plateauSize.Split('x')[0]);
            switch (direction)
            {
                case "N":
                    y += 1;
                    break;
                case "E":
                    x += 1;
                    break;
                case "S":
                    y -= 1;
                    break;
                case "W":
                    x -= 1;
                    break;
                default:
                    throw new ArgumentException();
            }

            if (x>xAxis)
            {
                x -= 1;
            }
            else if (x<=0)
            {
                x += 1;
            }
            else if (y>yAxis)
            {
                y -= 1;
            }
            else if (y<=0)
            {
                y += 1;
            }
        }

        //<Summary>
        //The rover instructions are looped. They change their directions or move forward/backward based on instruction.
        //</summary>
        //<params>
        //GridSize and rover instructions of string datatype is passed
        //</params>
        //<output>
        //null
        //</output>
        public void Move(string plateauSize,string roverCommand)
        {
            char[] instructions = roverCommand.ToCharArray();
            for(int i=0; i < instructions.Length; i++)
            {
                switch (instructions[i])
                {
                    case 'L':
                        SpinLeft();
                        break;
                    case 'R':
                        SpinRight();
                        break;
                    case 'F':
                        StepForward(plateauSize);
                        break;
                    default:
                        throw new ArgumentException();
                }
            }
        }

        //<Summary>
        //This function format the result as expected
        //</summary>
        //<params>
        //No argument
        //</params>
        //<output>
        //string
        //</output>
        public string OutputFormat()
        {
            string dir;
            switch (direction)
            {
                case "N":
                    dir = "North";
                    break;
                case "E":
                    dir = "East";
                    break;
                case "S":
                    dir = "South";
                    break;
                case "W":
                    dir = "West";
                    break;
                default:
                    throw new ArgumentException();
            }
            return x + "," + y + "," + dir;
        }

    }
}
