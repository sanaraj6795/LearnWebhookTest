﻿// See https://aka.ms/new-console-template for more information
using Rover;

MarsRover rover = new MarsRover("1 1 N");
//To get the grid size
string plateauSize = Console.ReadLine();
//to get the Rover Instruction
string roverCommand = Console.ReadLine();
//This fuctions is called to fetch the last pointed place and direction.
rover.Move(plateauSize, roverCommand);
//This method is called to formt the output
string finalPosition = rover.OutputFormat();
Console.WriteLine(finalPosition);




