using Rover;

namespace RoverTest
{
    public class UnitTest1
    {
        [Fact]
        public void SpinLeft()
        {
            //arrage
            MarsRover rover = new MarsRover("1 1 N");
            //act
            rover.SpinLeft();
           //assert
           Assert.Equal("W",rover.direction);
        }
        [Fact]
        public void SpinRight()
        {
            //arrage
            MarsRover rover = new MarsRover("1 1 N");
            //act
            rover.SpinRight();
            //assert
            Assert.Equal("E", rover.direction);
        }

        [Fact]
        public void StepForward()
        {
            //arrage
            MarsRover rover = new MarsRover("1 2 N");
            //act
            rover.StepForward("5x5");
            //assert
            Assert.Equal(3, rover.y);
        }

        [Fact]
        public void Move()
        {
            //arrage
            MarsRover rover = new MarsRover("1 1 N");
            //act
            rover.Move("5x5","FFRFLFLF");
            //assert
            Assert.Equal("1 4 W", rover.x + " " + rover.y+ " " +rover.direction);
        }

        [Fact]
        public void OutputFormat()
        {
            //arrage
            MarsRover rover = new MarsRover("1 1 N");
            //act
            rover.Move("5x5", "FFRFLFLF");
            string finalOutput = rover.OutputFormat();
            //assert
            Assert.Equal("1,4,West",finalOutput);
        }
    }
}